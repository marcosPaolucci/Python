lista =["carro","moto","barco"] 
try:   
    indice = int(input("Digite um indice de busca na lista: "))
    print(lista[indice])
except IndexError:
    print("Índice não encontrado")
    


