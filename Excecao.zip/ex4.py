try:
    num1 = int(input("Digite o 1o numero: "))
    num2 = int(input("Digite o 2o numero: "))
    resultado = num1 / num 2
except:
    print()
