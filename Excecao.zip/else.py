try:
    x = int(input("Digite o numerador: "))
    y = int(input("Digite o denominador: "))
    resultado = x / y
except ZeroDivisionError:
    print("Erro: não é posível dividir por zero")
except ValueError:
    print("Erro: Entrada inválida. Por favor, digite um numero inteiro")
else:
    print(f"Resultado: {resultado}")