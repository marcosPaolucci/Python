try:
    nome = input("Digite o nome do arquivo para abrir:")
    arquivo = open(f"{nome}.txt", "r")
    print(arquivo.read())
except FileNotFoundError:
    print("Arquivo não encontrado")