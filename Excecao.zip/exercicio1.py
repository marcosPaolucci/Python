try:
    numero = int(input("Digite um número: "))
except:
    print("Erro: Entrada inválida. Por favor, digite um numero inteiro")