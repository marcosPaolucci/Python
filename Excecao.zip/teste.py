try:
    numero = int(input("Digite um número: "))
    resultado = 10 / numero
    print(f"Resulado: {resultado}")
except ZeroDivisionError :
    print("Erro: não é possível dividir por zero")
except ValueError:
    print("Erro: Entrada inválida. Por favor, digite um numero inteiro")
finally:
    print("Bloco finally executado")

