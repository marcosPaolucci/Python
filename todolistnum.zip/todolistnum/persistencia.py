# persistencia.py
from pymongo import MongoClient

class TarefasDB:
    def __init__(self, host='localhost', port=27017, db_name='todolist'):
        self.client = MongoClient(host, port)
        self.db = self.client[db_name]
        self.tarefas_collection = self.db['tarefas']

    def cadastrar_tarefa(self, descricao, data_vencimento, status):
        tarefa = {
            'descricao': descricao,
            'data_vencimento': data_vencimento,
            'status': status
        }
        self.tarefas_collection.insert_one(tarefa)

    def listar_tarefas(self):
        return list(self.tarefas_collection.find())

    def editar_tarefa(self, tarefa_id, descricao=None, data_vencimento=None, status=None):
        update_data = {}
        if descricao:
            update_data['descricao'] = descricao
        if data_vencimento:
            update_data['data_vencimento'] = data_vencimento
        if status is not None:
            update_data['status'] = status

        self.tarefas_collection.update_one({'_id': tarefa_id}, {'$set': update_data})

    def remover_tarefa(self, tarefa_id):
        self.tarefas_collection.delete_one({'_id': tarefa_id})
