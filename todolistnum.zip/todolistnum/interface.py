# interface.py
from persistencia import TarefasDB
from tarefas import TarefasManager

def exibir_menu():
    print("1. Cadastrar Tarefa")
    print("2. Listar Tarefas")
    print("3. Sair")

def cadastrar_tarefa(tarefas_manager):
    descricao = input("Descrição da tarefa: ")
    data_vencimento = input("Data de vencimento (formato YYYY-MM-DD): ")
    tarefas_manager.cadastrar_tarefa(descricao, data_vencimento)

def listar_tarefas(tarefas_manager):
    tarefas = tarefas_manager.listar_tarefas()
    for tarefa in tarefas:
        print(f"{tarefa['num_tarefa']}. {tarefa['descricao']} (Vencimento: {tarefa['data_vencimento']}, Status: {'Concluída' if tarefa['status'] else 'Não Concluída'})")

def main():
    db = TarefasDB()
    tarefas_manager = TarefasManager(db)

    while True:
        exibir_menu()
        escolha = input("Escolha uma opção: ")

        if escolha == '1':
            cadastrar_tarefa(tarefas_manager)
        elif escolha == '2':
            listar_tarefas(tarefas_manager)
            opcao = input("Selecione o número da tarefa para editar ou remover, ou pressione Enter para voltar ao menu principal: ")
            if opcao:
                editar_remover_tarefa(tarefas_manager, int(opcao))
        elif escolha == '3':
            print("Saindo...")
            break
        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")

def editar_remover_tarefa(tarefas_manager, num_tarefa):
    tarefas = tarefas_manager.listar_tarefas()
    tarefa = next((tarefa for tarefa in tarefas if tarefa['num_tarefa'] == num_tarefa), None)
    if tarefa:
        opcao = input("Deseja editar ou remover esta tarefa? (E para editar, R para remover, Enter para voltar ao menu principal): ").upper()
        if opcao == 'E':
            editar_tarefa(tarefas_manager, tarefa['_id'])
        elif opcao == 'R':
            remover_tarefa(tarefas_manager, tarefa['_id'])
    else:
        print("Tarefa não encontrada.")

def editar_tarefa(tarefas_manager, tarefa_id):
    descricao = input("Nova descrição (deixe em branco para manter a mesma): ")
    data_vencimento = input("Nova data de vencimento (deixe em branco para manter a mesma): ")
    status = input("Novo status (True para concluída, False para não concluída, deixe em branco para manter o mesmo): ")
    tarefas_manager.editar_tarefa(tarefa_id, descricao, data_vencimento, status)

def remover_tarefa(tarefas_manager, tarefa_id):
    tarefas_manager.remover_tarefa(tarefa_id)

if __name__ == "__main__":
    main()
