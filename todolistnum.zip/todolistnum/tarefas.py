# tarefas.py
class TarefasManager:
    def __init__(self, db):
        self.db = db

    def cadastrar_tarefa(self, descricao, data_vencimento, status=False):
        self.db.cadastrar_tarefa(descricao, data_vencimento, status)

    def listar_tarefas(self):
        tarefas = self.db.listar_tarefas()
        num_tarefas = len(tarefas)
        for i, tarefa in enumerate(tarefas, start=1):
            tarefa['num_tarefa'] = i
        return tarefas

    def editar_tarefa(self, tarefa_id, descricao=None, data_vencimento=None, status=None):
        self.db.editar_tarefa(tarefa_id, descricao, data_vencimento, status)

    def remover_tarefa(self, tarefa_id):
        self.db.remover_tarefa(tarefa_id)
